package com.adobe.aem.assesment.core.bean;

public class Brand
{
    private String brandLogo;

    public String getBrandLogo ()
    {
        return brandLogo;
    }

    public void setBrandLogo (String brandLogo)
    {
        this.brandLogo = brandLogo;
    }
}
