package com.adobe.aem.assesment.core.serviceImpl;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.osgi.service.component.annotations.Component;

import com.adobe.aem.assesment.core.bean.ProductDataList;
import com.adobe.aem.assesment.core.service.ProductDataService;
import com.google.gson.Gson;

@Component(name = "Product Data Service", service = ProductDataService.class, immediate = true)
public class ProductDataServiceImpl implements ProductDataService {

	@Override
	public ProductDataList getProductDataList(String locale, String text) {
		ProductDataList productDataList = new ProductDataList();
		HttpClient client = HttpClientBuilder.create().build();
		StringBuilder sb = new StringBuilder();
		sb.append("https://www.philips.com/prx/product/B2C/");
		sb.append(locale);
		sb.append("/CONSUMER/products/");
		sb.append(text);
		sb.append(".summary");
        HttpGet getRequest = new HttpGet(sb.toString());
        getRequest.addHeader("accept", "application/json");

        try {
			HttpResponse response = client.execute(getRequest);
			String result = IOUtils.toString(response.getEntity().getContent(), StandardCharsets.UTF_8);
			productDataList = parseWatsonResults(result);
		} catch (IOException e) {
			e.printStackTrace();
		}
        return productDataList;

	}
	
	private ProductDataList parseWatsonResults(String responseString)
	{
		Gson gson = new Gson();
		
		return gson.fromJson(responseString, ProductDataList.class);
	}

}
