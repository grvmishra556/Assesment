package com.adobe.aem.assesment.core.service;

import com.adobe.aem.assesment.core.bean.ProductDataList;

public interface ProductDataService {

	ProductDataList getProductDataList(String locale, String text);

	
}
