package com.adobe.aem.assesment.core.bean;

public class ReviewStatistics
{
    private String averageOverallRating;

    private String totalReviewCount;

    public String getAverageOverallRating ()
    {
        return averageOverallRating;
    }

    public void setAverageOverallRating (String averageOverallRating)
    {
        this.averageOverallRating = averageOverallRating;
    }

    public String getTotalReviewCount ()
    {
        return totalReviewCount;
    }

    public void setTotalReviewCount (String totalReviewCount)
    {
        this.totalReviewCount = totalReviewCount;
    }

}