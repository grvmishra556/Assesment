package com.adobe.aem.assesment.core.bean;

public class Price
{
    private String formattedPrice;

    private String displayPrice;

    private String displayPriceType;

    private String formattedDisplayPrice;

    private String currencyCode;

    private String productPrice;

    public String getFormattedPrice ()
    {
        return formattedPrice;
    }

    public void setFormattedPrice (String formattedPrice)
    {
        this.formattedPrice = formattedPrice;
    }

    public String getDisplayPrice ()
    {
        return displayPrice;
    }

    public void setDisplayPrice (String displayPrice)
    {
        this.displayPrice = displayPrice;
    }

    public String getDisplayPriceType ()
    {
        return displayPriceType;
    }

    public void setDisplayPriceType (String displayPriceType)
    {
        this.displayPriceType = displayPriceType;
    }

    public String getFormattedDisplayPrice ()
    {
        return formattedDisplayPrice;
    }

    public void setFormattedDisplayPrice (String formattedDisplayPrice)
    {
        this.formattedDisplayPrice = formattedDisplayPrice;
    }

    public String getCurrencyCode ()
    {
        return currencyCode;
    }

    public void setCurrencyCode (String currencyCode)
    {
        this.currencyCode = currencyCode;
    }

    public String getProductPrice ()
    {
        return productPrice;
    }

    public void setProductPrice (String productPrice)
    {
        this.productPrice = productPrice;
    }

}
