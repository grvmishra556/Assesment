package com.adobe.aem.assesment.core.bean;

public class Data
{
    private String grpCode;

    private String eop;

    private String careSop;

    private String marketingTextHeader;

    private ReviewStatistics reviewStatistics;

    private String subCatRank;

    private String somp;

    private String descriptor;

    private String locale;

    private String subcategoryName;

    private String SEOProductName;

    private String isDeleted;

    private String sop;

    private Price price;

    private String familyName;

    private String imageURL;

    private String rank;

    private String productPagePath;

    private String ctn;

    private String grpNme;

    private Brand brand;

    private String wow;

    private String productType;

    private String dtn;

    private String alphanumeric;

    private String brandName;

    private String gtin;

    private String subWOW;

    private String[] filterKeys;

    private String categoryPath;

    private String productStatus;

    private String subcatCode;

    private String leafletUrl;

    private String catNme;

    private String priority;

    private String showOnlySupport;

    private String productTitle;

    private String catCode;

    private String[] versions;

    private Catalogs[] catalogs;

    private String domain;

    private String productURL;

    private String subcategory;

    private String accessory;

    public String getGrpCode ()
    {
        return grpCode;
    }

    public void setGrpCode (String grpCode)
    {
        this.grpCode = grpCode;
    }

    public String getEop ()
    {
        return eop;
    }

    public void setEop (String eop)
    {
        this.eop = eop;
    }

    public String getCareSop ()
    {
        return careSop;
    }

    public void setCareSop (String careSop)
    {
        this.careSop = careSop;
    }

    public String getMarketingTextHeader ()
    {
        return marketingTextHeader;
    }

    public void setMarketingTextHeader (String marketingTextHeader)
    {
        this.marketingTextHeader = marketingTextHeader;
    }

    public ReviewStatistics getReviewStatistics ()
    {
        return reviewStatistics;
    }

    public void setReviewStatistics (ReviewStatistics reviewStatistics)
    {
        this.reviewStatistics = reviewStatistics;
    }

    public String getSubCatRank ()
    {
        return subCatRank;
    }

    public void setSubCatRank (String subCatRank)
    {
        this.subCatRank = subCatRank;
    }

    public String getSomp ()
    {
        return somp;
    }

    public void setSomp (String somp)
    {
        this.somp = somp;
    }

    public String getDescriptor ()
    {
        return descriptor;
    }

    public void setDescriptor (String descriptor)
    {
        this.descriptor = descriptor;
    }

    public String getLocale ()
    {
        return locale;
    }

    public void setLocale (String locale)
    {
        this.locale = locale;
    }

    public String getSubcategoryName ()
    {
        return subcategoryName;
    }

    public void setSubcategoryName (String subcategoryName)
    {
        this.subcategoryName = subcategoryName;
    }

    public String getSEOProductName ()
    {
        return SEOProductName;
    }

    public void setSEOProductName (String SEOProductName)
    {
        this.SEOProductName = SEOProductName;
    }

    public String getIsDeleted ()
    {
        return isDeleted;
    }

    public void setIsDeleted (String isDeleted)
    {
        this.isDeleted = isDeleted;
    }

    public String getSop ()
    {
        return sop;
    }

    public void setSop (String sop)
    {
        this.sop = sop;
    }

    public Price getPrice ()
    {
        return price;
    }

    public void setPrice (Price price)
    {
        this.price = price;
    }

    public String getFamilyName ()
    {
        return familyName;
    }

    public void setFamilyName (String familyName)
    {
        this.familyName = familyName;
    }

    public String getImageURL ()
    {
        return imageURL;
    }

    public void setImageURL (String imageURL)
    {
        this.imageURL = imageURL;
    }

    public String getRank ()
    {
        return rank;
    }

    public void setRank (String rank)
    {
        this.rank = rank;
    }

    public String getProductPagePath ()
    {
        return productPagePath;
    }

    public void setProductPagePath (String productPagePath)
    {
        this.productPagePath = productPagePath;
    }

    public String getCtn ()
    {
        return ctn;
    }

    public void setCtn (String ctn)
    {
        this.ctn = ctn;
    }

    public String getGrpNme ()
    {
        return grpNme;
    }

    public void setGrpNme (String grpNme)
    {
        this.grpNme = grpNme;
    }

    public Brand getBrand ()
    {
        return brand;
    }

    public void setBrand (Brand brand)
    {
        this.brand = brand;
    }

    public String getWow ()
    {
        return wow;
    }

    public void setWow (String wow)
    {
        this.wow = wow;
    }

    public String getProductType ()
    {
        return productType;
    }

    public void setProductType (String productType)
    {
        this.productType = productType;
    }

    public String getDtn ()
    {
        return dtn;
    }

    public void setDtn (String dtn)
    {
        this.dtn = dtn;
    }

    public String getAlphanumeric ()
    {
        return alphanumeric;
    }

    public void setAlphanumeric (String alphanumeric)
    {
        this.alphanumeric = alphanumeric;
    }

    public String getBrandName ()
    {
        return brandName;
    }

    public void setBrandName (String brandName)
    {
        this.brandName = brandName;
    }

    public String getGtin ()
    {
        return gtin;
    }

    public void setGtin (String gtin)
    {
        this.gtin = gtin;
    }

    public String getSubWOW ()
    {
        return subWOW;
    }

    public void setSubWOW (String subWOW)
    {
        this.subWOW = subWOW;
    }

    public String[] getFilterKeys ()
    {
        return filterKeys;
    }

    public void setFilterKeys (String[] filterKeys)
    {
        this.filterKeys = filterKeys;
    }

    public String getCategoryPath ()
    {
        return categoryPath;
    }

    public void setCategoryPath (String categoryPath)
    {
        this.categoryPath = categoryPath;
    }

    public String getProductStatus ()
    {
        return productStatus;
    }

    public void setProductStatus (String productStatus)
    {
        this.productStatus = productStatus;
    }

    public String getSubcatCode ()
    {
        return subcatCode;
    }

    public void setSubcatCode (String subcatCode)
    {
        this.subcatCode = subcatCode;
    }

    public String getLeafletUrl ()
    {
        return leafletUrl;
    }

    public void setLeafletUrl (String leafletUrl)
    {
        this.leafletUrl = leafletUrl;
    }

    public String getCatNme ()
    {
        return catNme;
    }

    public void setCatNme (String catNme)
    {
        this.catNme = catNme;
    }

    public String getPriority ()
    {
        return priority;
    }

    public void setPriority (String priority)
    {
        this.priority = priority;
    }

    public String getShowOnlySupport ()
    {
        return showOnlySupport;
    }

    public void setShowOnlySupport (String showOnlySupport)
    {
        this.showOnlySupport = showOnlySupport;
    }

    public String getProductTitle ()
    {
        return productTitle;
    }

    public void setProductTitle (String productTitle)
    {
        this.productTitle = productTitle;
    }

    public String getCatCode ()
    {
        return catCode;
    }

    public void setCatCode (String catCode)
    {
        this.catCode = catCode;
    }

    public String[] getVersions ()
    {
        return versions;
    }

    public void setVersions (String[] versions)
    {
        this.versions = versions;
    }

    public Catalogs[] getCatalogs ()
    {
        return catalogs;
    }

    public void setCatalogs (Catalogs[] catalogs)
    {
        this.catalogs = catalogs;
    }

    public String getDomain ()
    {
        return domain;
    }

    public void setDomain (String domain)
    {
        this.domain = domain;
    }

    public String getProductURL ()
    {
        return productURL;
    }

    public void setProductURL (String productURL)
    {
        this.productURL = productURL;
    }

    public String getSubcategory ()
    {
        return subcategory;
    }

    public void setSubcategory (String subcategory)
    {
        this.subcategory = subcategory;
    }

    public String getAccessory ()
    {
        return accessory;
    }

    public void setAccessory (String accessory)
    {
        this.accessory = accessory;
    }

}