package com.adobe.aem.assesment.core.bean;

public class Catalogs
{
    private String catalogId;

    private String visibility;

    private String isDeleted;

    private String sop;

    private String eop;

    private String rank;

    private String clearance;

    private String somp;

    private String priority;

    private String status;

    public String getCatalogId ()
    {
        return catalogId;
    }

    public void setCatalogId (String catalogId)
    {
        this.catalogId = catalogId;
    }

    public String getVisibility ()
    {
        return visibility;
    }

    public void setVisibility (String visibility)
    {
        this.visibility = visibility;
    }

    public String getIsDeleted ()
    {
        return isDeleted;
    }

    public void setIsDeleted (String isDeleted)
    {
        this.isDeleted = isDeleted;
    }

    public String getSop ()
    {
        return sop;
    }

    public void setSop (String sop)
    {
        this.sop = sop;
    }

    public String getEop ()
    {
        return eop;
    }

    public void setEop (String eop)
    {
        this.eop = eop;
    }

    public String getRank ()
    {
        return rank;
    }

    public void setRank (String rank)
    {
        this.rank = rank;
    }

    public String getClearance ()
    {
        return clearance;
    }

    public void setClearance (String clearance)
    {
        this.clearance = clearance;
    }

    public String getSomp ()
    {
        return somp;
    }

    public void setSomp (String somp)
    {
        this.somp = somp;
    }

    public String getPriority ()
    {
        return priority;
    }

    public void setPriority (String priority)
    {
        this.priority = priority;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

}
